# GitPHP — Self-Hosted Code Platform

A full-featured GitHub-like code hosting platform built with pure PHP, HTML, and CSS (Tailwind). No frameworks, no Composer dependencies — just drop it in and go.

## Features

- **Repository management** — Create public or private repositories
- **ZIP upload** — Upload entire projects as ZIP files (up to 100MB)
- **Auto .gitignore** — `build/`, `dist/`, `node_modules/`, `.git/`, `vendor/` and more are automatically excluded on upload
- **File browser** — Navigate directory trees with folder-first sorting
- **Code editor** — Edit files in-browser with tab support, auto-resize, and Ctrl+S to save
- **README rendering** — Full Markdown renderer with syntax highlighting, tables, task lists, and code blocks
- **Syntax highlighting** — Language detection for 30+ file types
- **Language stats** — Visual language bar showing project composition
- **Star repos** — Star/unstar public repositories
- **User profiles** — Public profile pages with repo listings
- **Smart caching** — File-based cache with WAL SQLite for fast reads
- **Gzip output** — Automatic response compression
- **Modern UI** — Dark theme, DM Sans + JetBrains Mono fonts, Lucide icons

## Requirements

- PHP 8.1+ with extensions: `pdo_sqlite`, `zip`, `fileinfo`
- Apache with `mod_rewrite` **or** Nginx **or** PHP built-in server

## Quick Start (Local Dev)

```bash
cd gitphp
php -S localhost:8080 router.php
```
Then open http://localhost:8080

## Apache Setup

```bash
# Copy files to your webroot
cp -r gitphp/ /var/www/html/gitphp/

# Ensure mod_rewrite is enabled
sudo a2enmod rewrite
sudo systemctl restart apache2
```

Make sure `AllowOverride All` is set for your document root in Apache config.

## Nginx Setup

Copy `nginx.conf` to `/etc/nginx/sites-available/gitphp` and adjust the `root` path, then:

```bash
sudo ln -s /etc/nginx/sites-available/gitphp /etc/nginx/sites-enabled/
sudo systemctl reload nginx
```

## Directory Structure

```
gitphp/
├── index.php          # Main entry point + all page rendering
├── router.php         # PHP built-in server router
├── .htaccess          # Apache URL rewriting + security
├── nginx.conf         # Nginx config reference
├── gitphp.db          # SQLite database (auto-created)
├── includes/
│   ├── config.php     # App config, DB, helper functions
│   ├── controllers.php # Page/API handlers
│   ├── repofs.php     # Repository filesystem manager
│   └── markdown.php   # Markdown → HTML renderer
├── repos/             # Repository files (username/reponame/)
├── uploads/           # Temp upload storage (auto-cleared)
└── cache/             # File-based output cache
```

## Ignored Paths (Auto .gitignore)

When uploading a ZIP, these are automatically skipped:

| Pattern | Reason |
|---------|--------|
| `build/` | Build artifacts |
| `dist/` | Distribution builds |
| `node_modules/` | NPM packages |
| `.git/` | Git internals |
| `vendor/` | Composer packages |
| `__pycache__/` | Python cache |
| `.env` | Environment secrets |
| `*.log` | Log files |
| `.DS_Store` | macOS metadata |
| `.idea/`, `.vscode/` | IDE configs |
| `coverage/` | Test coverage |
| `.next/`, `.nuxt/` | Framework builds |

## Security Notes

- Repository files, uploads, cache, and the SQLite DB are blocked from direct web access via `.htaccess`/nginx rules
- All user input is sanitized with `htmlspecialchars()`
- File paths are validated against path traversal (`realpath()` check)
- ZIP extraction enforces 100MB limit before extracting
- Passwords are hashed with `password_hash(PASSWORD_BCRYPT)`

## Performance

- SQLite WAL mode + `PRAGMA cache_size=10000` for fast concurrent reads
- File-based cache with 60s TTL for repo stats and Markdown renders
- Gzip output compression (6-level)
- HTTP cache headers (`Cache-Control: public, max-age=30`) on public pages
- Minimal external dependencies — only Tailwind CDN, Lucide CDN, Google Fonts

## License

MIT — use freely for personal or commercial self-hosting.
